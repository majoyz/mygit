#include "head.h"
#include "tran_n.h"

int myregister(int);
int login(int);
