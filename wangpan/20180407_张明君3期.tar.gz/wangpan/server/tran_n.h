#include "head.h"

int send_n(int,void *,size_t);
int recv_n(int,void *,size_t);
